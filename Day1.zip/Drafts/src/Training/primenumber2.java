package Training;

public class primenumber2 {

	public static void main(String[] args) {
		//int res=add(10,20)
		//System.out.println(res);
		add (10,20);

	}
	static void add(int a,int b) {
		System.out.println(a+b);
	}

}
