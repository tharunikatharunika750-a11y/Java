package Training;

public class H2 {
    public static void main(String[] args) {
        add(10, 20);
    }

    static void add(int a, int b) {
        System.out.println(a + b);
    }
}
