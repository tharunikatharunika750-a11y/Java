package Training;

public class primenumbers3 {

	public static void main(String[] args) {
		add(20,30);		
		add(20,30,40);
		add(20,30,40,50);
	}
		
	static void add(int a,int b) {
		System.out.println(a+b);
	}
	static void add(int a,int b,int c) {
		System.out.println(a+b+c);
	}
	static void add(int a,int b,int c,int d) {
		System.out.println(a+b+c+d);
	}

}