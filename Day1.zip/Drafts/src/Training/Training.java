package Training;

public class Training {

	public static void main(String[] args) {
		int res=add(10,20);
		System.out.println(res);

	}
	static int add(int a,int b) {
		return a+b;
	}

}
