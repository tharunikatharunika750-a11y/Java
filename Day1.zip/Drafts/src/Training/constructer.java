package Training;

public class constructer {
	String col;
	String com;
	float price;
	
	public constructer() {
		System.out.println("constructor");
	}
	public constructer(String col,String com,float price) {
		System.out.println(col);
		System.out.println(com);
		System.out.println(price);
	}

	public static void main(String[] args) {
		System.out.println("main");
		constructer c1=new constructer();
		System.out.println(c1);
		constructer c2=new constructer("red","DOMS",10.0f);

	}

}