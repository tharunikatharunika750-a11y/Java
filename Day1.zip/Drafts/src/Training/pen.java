package Training;

public class pen {
	String col;
	String com;
	float price;
	
	public pen(String color,String company,float pricecost) {
		this("red","class");
		this.col=color;
		this.com=company;
		this.price=pricecost;
		System.out.println("cos with 3 val");
	}
	public pen(String color,String company) {
		this("red");
		this.col=color;
		this.com=company;
		System.out.println("cos with 2 val");
		
	}
	public pen(String color) {
		//this("red","class",10.0f);
		System.out.println("cons with 1 val");
	}

	public static void main(String[] args) {
		System.out.println("main");
		pen p1=new pen("red","DOMS",10.0f);
		System.out.println(p1.col);
		System.out.println(p1.com);
		System.out.println(p1.price);

	}

}


